<?php   

    $email = $firstName = $lastName = $howDidYouHear = "";
    
    if($_SERVER["REQUEST_METHOD"] == "GET"){
        $posted = True;
        if(!empty($_GET["email"])){
            $email = test_input($_GET["email"]);
        }
        
        if(!empty($_GET["firstName"])){
            $firstName = test_input($_GET["firstName"]);
        }

        if(!empty($_GET["lastName"])){
            $lastName = test_input($_GET["lastName"]);
        }

        if(!empty($_GET["howDidYouHear"])){
            $howDidYouHear = test_input($_GET["howDidYouHear"]);
        }
        $userData = [
            'id' => NULL,
            'email'=> $email,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'howDidYouHear' => $howDidYouHear,
            'numberOfVisits' => 1
        ];

        include_once('database.php');
        include_once('mailchimp.php');

        // get user from the database (try to, null if not found)
        $userInformation = getUser($email);
        if ($userInformation == NULL){
            // if the user was not found, add them to the database and to mailchimp
            insertUser($userData);
            $httpCode = addToMailChimp($userData);

            http_response_code(201);
            echo "created";
        }
        else {
            // if the user was found, add 1 to the 'numberOfVisists' then update user
            $userData['id'] =$userInformation['id'];
            $userData['numberOfVisits'] = $userInformation['numberOfVisits'] + 1;

            updateUser($userData);

            http_response_code(200);
            echo "updated";
        }

    }
    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>