<?php
include_once('credentials.php');

    function getUser($emailAddress) {
        // connect to the database
        $connection = new mysqli(DBHOST, DBUSERNAME ,DBPASSWORD, DBNAME);
        if ($connection->connect_error) {
            die("Connection failed: " . $connection->connect_error); //any reason if can't log into database
            // stop executing
        }
 
        $sql = "SELECT `id`, `email`, `firstName`, `lastName`, `howDidYouHear`, `numberOfVisits` FROM `contacts` WHERE `email` = ?";
        $statement = $connection->prepare($sql);
        // bind our email parameter to the sql we are sending
        $statement->bind_param("s", $emailAddress);
        $statement->execute();
        $result = $statement->get_result();
        // get a single result (our user record)
        $contact= $result->fetch_array(MYSQLI_ASSOC);
        $result->close();
        $connection->close();

        return $contact;
    }

    function insertUser($data){
        $connection = new mysqli(DBHOST, DBUSERNAME ,DBPASSWORD, DBNAME);
        if ($connection->connect_error) {
            die("Connection failed: " . $connection->connect_error);
        }

        $sqlInsert = $connection ->prepare("INSERT INTO `contacts`(`email`, `firstName`, `lastName`, `howDidYouHear`, `numberOfVisits`) VALUES (?, ?, ?, ?, ?)");
        $sqlInsert->bind_param("ssssi", $data['email'], $data['firstName'], $data['lastName'], $data['howDidYouHear'], $data['numberOfVisits']);
        $sqlInsert->execute();

        $sqlInsert->close();
        $connection -> close();
    }

    function updateUser($data){
        $connection = new mysqli(DBHOST, DBUSERNAME ,DBPASSWORD, DBNAME);
        if ($connection->connect_error) {
            die("Connection failed: " . $connection->connect_error);
        }

        $sqlUpdate = $connection ->prepare("UPDATE `contacts` SET `firstName`=?, `lastName`=?,`howDidYouHear`=?,`numberOfVisits`=? WHERE `id`=?");
        $sqlUpdate->bind_param("sssii", $data['firstName'], $data['lastName'], $data['howDidYouHear'], $data['numberOfVisits'], $data['id']);
        $sqlUpdate->execute();

        $sqlUpdate->close();
        $connection -> close();
    }

    
    try{

        
        
    }
    catch(Exception  $e){
        echo "Error: " . $e->getMessage();
    }
    $connection = null;

?>