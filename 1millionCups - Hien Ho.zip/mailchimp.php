<?php

include_once('credentials.php');

function addToMailChimp($data){
    $apiKey = MAILCHIMP_API_KEY;
    $listId = MAILCHIMP_AUDIENCE_ID;
    $memberId = md5(strtolower($data['email']));
    $dataCenter = substr($apiKey, strpos($apiKey, '-')+1);

    $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listId . '/members/';

    if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else{
        $ip_address = $_SERVER['REMOTE_ADDR'];
    }

    $json = json_encode([
        'email_address' => $data['email'],
        'status'        => 'subscribed', //'subscribed', 'unsubcribed', 'cleaned', 'pending'
        'ip_signup'     => $ip_address,
        'merge_fields'  =>[
            'FNAME'     => $data['firstName'],
            'LNAME'     => $data['lastName']
        ]
    ]);

    $postData = array(
        "email_address" => $data['email'], 
        "status" => "subscribed", 
        "merge_fields" => array(
        "FNAME"=> $data["firstName"],
        "LNAME"=> $data["lastName"])
    );

    $httpCode = null;
    // printRequestInfo($url, $json);
    $httpCode = executeRequest($url, $postData);

    //print_r($httpCode);

    return $httpCode;
}

function executeRequest($url, $json){
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_POST => TRUE,
        CURLOPT_RETURNTRANSFER => TRUE,
        CURLOPT_HTTPHEADER => array(
            'Authorization: apikey '.MAILCHIMP_API_KEY,
            'Content-Type: application/json'
        ),
        CURLOPT_POSTFIELDS => json_encode($json)
    ));
    //curl_setopt($ch, CURLOPT_USERPWD, 'user:' . MAILCHIMP_API_KEY);
    
    // curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    //     'Authorization: apikey '.MAILCHIMP_API_KEY,
    //     'Content-Type: application/json'
    // ));
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    // curl_setopt($ch, CURLOPT_CUSTOMEREQUEST, 'POST');
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, $json);

    $request = curl_exec($ch);
    
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $httpCode;

}

?>