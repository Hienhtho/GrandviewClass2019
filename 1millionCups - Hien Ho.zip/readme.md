//Installation

Database setup
Create a table with the following fields
1	idPrimary	       int(11)			     NoNone		       AUTO_INCREMENT
2	email	         varchar(255)	    utf8_general_ci		      No	None		
3	firstName	     varchar(255)	    utf8_general_ci		      No	None		
4	lastName	     varchar(255)	    utf8_general_ci		      No	None		
5	howDidYouHear	 varchar(4096)	    utf8_general_ci		      No	None		
6	numberOfVisits	  int(11)			    No	None		
Update credential.php with database host, database name, table name, database username, database password


Create mailchimp account
Create an API Key: 
    Navigate to the APIs & Services→Credentials panel in GCP Console.
    Select Create credentials, then select API key from the dropdown menu.
    Click the Create button. The API key created dialog box displays your newly created key.
Get audienceId (This is the id of your mailchimp list)
Update credentail.php with audience_Id and api_key


Host the webpage on a server with php
    Create a lightsail account
    Installing WINSCP to upload the files to Amazon Lightsail server

