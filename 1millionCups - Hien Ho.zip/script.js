function sumbmitFormAjax(e){
    e.preventDefault();
    
    var email = document.getElementById('email').value;
    var firstName = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var howDidYouHear = document.getElementById('howDidYouHear').value;

    var xmlhttp;

    if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
    } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status === 200) {
                showWelcomeBack();
            } else {
                showThankYou();
            }
        }
    };
    xmlhttp.open("GET","add_contact.php?action=register_user&firstName="+firstName+"&lastName="+lastName+"&email="+email+"&howDidYouHear="+howDidYouHear,true);
    xmlhttp.send();

    return false;
}

function showForm() {
    var element = document.getElementById('signup-form');
    element.classList.remove("hidden");
    document.getElementById('thank-you').classList.add("hidden");
    document.getElementById('welcome-back').classList.add("hidden");
}

function showThankYou() {
    document.getElementById('signup-form').classList.add("hidden");
    document.getElementById('thank-you').classList.remove("hidden");
    document.getElementById('welcome-back').classList.add("hidden");
}

function showWelcomeBack() {
    document.getElementById('signup-form').classList.add("hidden");
    document.getElementById('thank-you').classList.add("hidden");
    document.getElementById('welcome-back').classList.remove("hidden");
}